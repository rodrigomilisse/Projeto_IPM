window.onload = function () {
	// Get today's date
	const today = new Date();

	// Function to get day name (e.g., 'Monday')
	const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

	// Function to format the label (e.g., 'Today', 'Yesterday', 'Monday', etc.)
	function getFormattedDate(date) {
		const day = date.getDay(); // Get the day of the week (0-6)
		return dayNames[day];
	}

	// Generate the labels: 6 previous days, and "Today" as the last
	const labels = [
		getFormattedDate(new Date(today.setDate(today.getDate() - 6))), // 6 days ago
		getFormattedDate(new Date(today.setDate(today.getDate() + 1))), // 5 days ago
		getFormattedDate(new Date(today.setDate(today.getDate() + 1))), // 4 days ago
		getFormattedDate(new Date(today.setDate(today.getDate() + 1))), // 3 days ago
		getFormattedDate(new Date(today.setDate(today.getDate() + 1))), // 2 days ago
		getFormattedDate(new Date(today.setDate(today.getDate() + 1))), // 1 day ago
		'Today'  // Today at the end
	];

	// Define an array of chart configurations
	const charts = [
		{ id: 'temperatureChart', title: 'Temperature', unit: 'ºC', data: [24, 23, 22, 24, 25, 26, 27] },
		{ id: 'humidityChart', title: 'Humidity', unit: '%', data: [65, 66, 64, 62, 61, 63, 65] },
		{ id: 'rainChart', title: 'Rain', unit: 'mm', data: [0, 5, 0, 10, 0, 0, 0] },
		{ id: 'windChart', title: 'Wind', unit: 'km/h', data: [30, 35, 40, 45, 30, 32, 30] },
		{ id: 'consumptionChart', title: 'Consumption', unit: 'L/day', data: [180, 190, 200, 210, 220, 230, 240] }
	];

	// Function to plot a chart
	function plotChart(canvasId, chartTitle, units, data) {
		var ctx = document.getElementById(canvasId).getContext('2d');
		new Chart(ctx, {
			type: 'line',
			data: {
				labels: labels,  // Generated dynamic labels
				datasets: [{
					label: chartTitle,
					data: data,  // Data passed dynamically
					borderColor: 'green',
					fill: false
				}]
			},
			options: {
				responsive: true,
				scales: {
					y: {
						title: {
							display: true,
							text: units  // Display unit as Y-axis label
						}
					}
				}
			}
		});
	}

	// Automatically plot all charts from the charts array
	charts.forEach(chart => {
		plotChart(chart.id, chart.title, chart.unit, chart.data);
	});
};
